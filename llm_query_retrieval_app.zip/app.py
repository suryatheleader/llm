
# LLM-Powered Query-Retrieval System with DB Integration, Streamlit UI, and Docker Compose

# Requirements: pip install langchain openai pinecone-client python-docx pypdf tiktoken extract-msg streamlit

import os
import json
import glob
import streamlit as st
from langchain.chat_models import ChatOpenAI
from langchain.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Pinecone
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains import RetrievalQA
import pinecone

# --- 1. Load Documents ---
def load_documents(directory="./docs"):
    all_docs = []

    for filepath in glob.glob(f"{directory}/*.pdf"):
        all_docs.extend(PyPDFLoader(filepath).load())

    for filepath in glob.glob(f"{directory}/*.docx"):
        all_docs.extend(Docx2txtLoader(filepath).load())

    for filepath in glob.glob(f"{directory}/*.eml"):
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            all_docs.append({"page_content": content, "metadata": {"source": filepath}})

    return all_docs

# --- 2. Split into Chunks ---
def split_documents(docs):
    splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    return splitter.split_documents(docs)

# --- 3. Embed & Store in Pinecone ---
def create_vector_store(chunks):
    pinecone.init(api_key=os.getenv("PINECONE_API_KEY"), environment=os.getenv("PINECONE_ENV"))
    index_name = "llm-query-index"
    if index_name not in pinecone.list_indexes():
        pinecone.create_index(index_name, dimension=1536)
    embeddings = OpenAIEmbeddings()
    return Pinecone.from_documents(chunks, embeddings, index_name=index_name)

# --- 4. Create RetrievalQA Chain ---
def create_qa_chain(vector_store):
    retriever = vector_store.as_retriever()
    llm = ChatOpenAI(temperature=0)
    return RetrievalQA.from_chain_type(llm=llm, retriever=retriever, chain_type="stuff")

# --- 5. Run Query & Generate Structured JSON ---
def query_and_explain(qa_chain, query, vector_store):
    response = qa_chain.run(query)
    matched_docs = vector_store.similarity_search(query, k=3)

    return {
        "query": query,
        "answer": response,
        "matched_clauses": [doc.page_content for doc in matched_docs],
        "rationale": "The LLM used semantic search to find the most relevant clauses and extracted the contextual answer."
    }

# --- 6. Streamlit UI ---
st.title("📄 LLM-Powered Clause Retrieval")
st.markdown("Upload documents and ask natural language questions.")

uploaded_files = st.file_uploader("Upload documents", type=["pdf", "docx", "eml"], accept_multiple_files=True)
query = st.text_input("Ask your question")

if uploaded_files and query:
    # Save uploaded files temporarily
    os.makedirs("temp_docs", exist_ok=True)
    for file in uploaded_files:
        with open(f"temp_docs/{file.name}", "wb") as f:
            f.write(file.getvalue())

    docs = load_documents("temp_docs")
    chunks = split_documents(docs)
    vector_store = create_vector_store(chunks)
    qa_chain = create_qa_chain(vector_store)
    result = query_and_explain(qa_chain, query, vector_store)

    st.subheader("Answer")
    st.write(result["answer"])
    st.subheader("Matched Clauses")
    for clause in result["matched_clauses"]:
        st.code(clause, language='markdown')
    st.subheader("Rationale")
    st.write(result["rationale"])

    # Cleanup
    for file in uploaded_files:
        os.remove(f"temp_docs/{file.name}")
    os.rmdir("temp_docs")
